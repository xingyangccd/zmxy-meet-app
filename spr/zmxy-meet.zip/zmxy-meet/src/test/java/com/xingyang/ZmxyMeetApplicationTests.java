package com.xingyang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZmxyMeetApplicationTests {

    @Test
    void contextLoads() {
    }

}
