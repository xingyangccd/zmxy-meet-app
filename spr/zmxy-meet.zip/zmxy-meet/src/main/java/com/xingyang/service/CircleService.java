package com.xingyang.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.xingyang.entity.Circle;

public interface CircleService extends IService<Circle> {
}
