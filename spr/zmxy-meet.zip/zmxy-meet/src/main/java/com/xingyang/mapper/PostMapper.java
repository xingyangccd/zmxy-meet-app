package com.xingyang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingyang.entity.Post;

public interface PostMapper extends BaseMapper<Post> {
}
