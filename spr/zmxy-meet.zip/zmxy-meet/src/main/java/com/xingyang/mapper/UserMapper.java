package com.xingyang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingyang.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
