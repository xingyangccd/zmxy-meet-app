package com.xingyang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingyang.entity.Relation;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RelationMapper extends BaseMapper<Relation> {
}
