package com.xingyang.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.xingyang.entity.Message;

public interface MessageMapper extends BaseMapper<Message> {
}
